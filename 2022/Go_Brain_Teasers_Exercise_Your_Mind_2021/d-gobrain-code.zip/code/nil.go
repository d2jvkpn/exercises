package main

import (
	"fmt"
)

func main() {
	n := nil
	fmt.Println(n)
}
