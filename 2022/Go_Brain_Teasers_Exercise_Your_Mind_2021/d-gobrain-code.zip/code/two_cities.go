package main

import (
	"fmt"
)

func main() {
	city1, city2 := "Kraków", "Kraków"
	fmt.Println(city1 == city2)
}
