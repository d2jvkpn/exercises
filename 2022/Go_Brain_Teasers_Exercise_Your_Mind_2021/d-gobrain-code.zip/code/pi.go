package main

import (
	"fmt"
)

func main() {
	var π = 22 / 7.0
	fmt.Println(π)
}
