package main

import (
	"fmt"
)

func main() {
	a, b := 22, 7.0
	var π = a / b
	fmt.Println(π)
}
