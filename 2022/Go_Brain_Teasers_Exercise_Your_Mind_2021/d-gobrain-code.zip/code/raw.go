package main

import (
	"fmt"
)

func main() {
	s := `a\tb`
	fmt.Println(s)
}
