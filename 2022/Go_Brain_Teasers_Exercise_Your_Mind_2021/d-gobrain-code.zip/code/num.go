package main

import (
	"fmt"
)

func main() {
	fmt.Println(0x1p-2)
}
