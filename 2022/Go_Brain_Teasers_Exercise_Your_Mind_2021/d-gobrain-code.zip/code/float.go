package main

import (
	"fmt"
)

func main() {
	n := 1.1
	fmt.Println(n * n)
}
